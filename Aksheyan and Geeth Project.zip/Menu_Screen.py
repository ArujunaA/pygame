import pygame
from sys import exit  #whenever called, the program will close (secure way of exiting program)

#launches pygame module
pygame.init()

screen = pygame.display.set_mode((1100,600))
clock = pygame.time.Clock()
pygame.display.set_caption("Kaleb's Time Machine")

background_image = pygame.image.load("menubg.png").convert()

title_banner = pygame.image.load("title.png")

#note that the buttons were resized
play_button = pygame.image.load("play.png")
resized_play = pygame.transform.scale(play_button,(128,48))

quiz_button = pygame.image.load("quiz.png")
resized_quiz = pygame.transform.scale(quiz_button,(128,48))

results_button = pygame.image.load("results.png")
resized_results = pygame.transform.scale(results_button,(128,48))

lesson_button = pygame.image.load("lesson.png")
resized_lesson = pygame.transform.scale(lesson_button,(128,48))

quit_button = pygame.image.load("quit.png")
resized_quit = pygame.transform.scale(quit_button,(128,48))

#main game loop
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
    screen.blit(background_image,(0,0))
    screen.blit(title_banner,(233,57))
    screen.blit(resized_quit,(200,275))
    screen.blit(resized_lesson,(350,275))
    screen.blit(resized_play,(500,275))
    screen.blit(resized_quiz,(650,275))
    screen.blit(resized_results,(800,275))
    #draws all our elements
    #update everything
    pygame.display.update()
    clock.tick(60) #sets the max framrate for the menu as 60 fps